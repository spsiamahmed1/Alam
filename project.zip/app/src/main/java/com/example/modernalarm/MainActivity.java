package com.example.modernalarm;

import android.Manifest;
import android.app.AlarmManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.materialswitch.MaterialSwitch;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recycler;
    private TextView tvEmpty;
    private AlarmAdapter adapter;
    private List<Alarm> alarms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recycler = findViewById(R.id.recycler);
        tvEmpty = findViewById(R.id.tvEmpty);
        FloatingActionButton fab = findViewById(R.id.fab);

        alarms = AlarmStore.load(this);
        adapter = new AlarmAdapter();
        recycler.setLayoutManager(new LinearLayoutManager(this));
        recycler.setAdapter(adapter);
        updateEmpty();

        fab.setOnClickListener(v -> showAddDialog());
        askPermissions();
    }

    private void askPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
            if (am != null && !am.canScheduleExactAlarms()) {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                            Uri.parse("package:" + getPackageName())));
                } catch (Exception ignored) {
                }
            }
        }
    }

    private void showAddDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(40, 20, 40, 0);

        TimePicker picker = new TimePicker(this);
        picker.setIs24HourView(false);
        box.addView(picker);

        EditText etLabel = new EditText(this);
        etLabel.setHint(R.string.label_hint);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 24;
        etLabel.setLayoutParams(lp);
        box.addView(etLabel);

        new AlertDialog.Builder(this)
                .setTitle(R.string.add_alarm)
                .setView(box)
                .setPositiveButton(R.string.save, (d, w) -> {
                    int h, m;
                    if (Build.VERSION.SDK_INT >= 23) {
                        h = picker.getHour();
                        m = picker.getMinute();
                    } else {
                        h = picker.getCurrentHour();
                        m = picker.getCurrentMinute();
                    }
                    Alarm a = new Alarm(System.currentTimeMillis(), h, m,
                            etLabel.getText().toString().trim(), true);
                    alarms.add(a);
                    AlarmStore.save(this, alarms);
                    AlarmScheduler.schedule(this, a);
                    adapter.notifyDataSetChanged();
                    updateEmpty();
                    Toast.makeText(this, "অ্যালার্ম সেট হয়েছে", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void updateEmpty() {
        tvEmpty.setVisibility(alarms.isEmpty() ? View.VISIBLE : View.GONE);
    }

    // ================== Adapter (inner) ==================
    private class AlarmAdapter extends RecyclerView.Adapter<AlarmAdapter.VH> {

        class VH extends RecyclerView.ViewHolder {
            TextView tvTime, tvLabel;
            MaterialSwitch sw;
            ImageButton btnDelete;

            VH(View v) {
                super(v);
                tvTime = v.findViewById(R.id.tvTime);
                tvLabel = v.findViewById(R.id.tvLabel);
                sw = v.findViewById(R.id.swEnabled);
                btnDelete = v.findViewById(R.id.btnDelete);
            }
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            CardView card = new CardView(parent.getContext());
            RecyclerView.LayoutParams cLP = new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            cLP.bottomMargin = 24;
            card.setLayoutParams(cLP);
            card.setRadius(48f);
            card.setCardElevation(0f);
            card.setCardBackgroundColor(0x33FFFFFF);

            LinearLayout row = new LinearLayout(parent.getContext());
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(36, 36, 36, 36);

            LinearLayout col = new LinearLayout(parent.getContext());
            col.setOrientation(LinearLayout.VERTICAL);
            col.setLayoutParams(new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView tvTime = new TextView(parent.getContext());
            tvTime.setId(R.id.tvTime);
            tvTime.setTextColor(0xFFFFFFFF);
            tvTime.setTextSize(28f);
            tvTime.setTypeface(null, Typeface.BOLD);
            col.addView(tvTime);

            TextView tvLabel = new TextView(parent.getContext());
            tvLabel.setId(R.id.tvLabel);
            tvLabel.setTextColor(0xB3FFFFFF);
            tvLabel.setTextSize(13f);
            col.addView(tvLabel);

            row.addView(col);

            MaterialSwitch sw = new MaterialSwitch(parent.getContext());
            sw.setId(R.id.swEnabled);
            row.addView(sw);

            ImageButton btnDel = new ImageButton(parent.getContext());
            btnDel.setId(R.id.btnDelete);
            btnDel.setImageResource(R.drawable.ic_delete);
            btnDel.setBackground(null);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(100, 100);
            dlp.leftMargin = 12;
            btnDel.setLayoutParams(dlp);
            row.addView(btnDel);

            card.addView(row);
            return new VH(card);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Alarm a = alarms.get(position);
            h.tvTime.setText(a.formattedTime());
            h.tvLabel.setText(a.label == null || a.label.isEmpty() ? " " : a.label);

            h.sw.setOnCheckedChangeListener(null);
            h.sw.setChecked(a.enabled);
            h.sw.setOnCheckedChangeListener((btn, checked) -> {
                a.enabled = checked;
                AlarmStore.save(MainActivity.this, alarms);
                if (checked) AlarmScheduler.schedule(MainActivity.this, a);
                else AlarmScheduler.cancel(MainActivity.this, a);
            });

            h.btnDelete.setOnClickListener(v -> {
                alarms.remove(a);
                AlarmStore.save(MainActivity.this, alarms);
                AlarmScheduler.cancel(MainActivity.this, a);
                notifyDataSetChanged();
                updateEmpty();
            });
        }

        @Override
        public int getItemCount() {
            return alarms.size();
        }
    }
}
