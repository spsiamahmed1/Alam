package com.example.modernalarm;

public class Alarm {
    public long id;
    public int hour;
    public int minute;
    public String label;
    public boolean enabled;

    public Alarm(long id, int hour, int minute, String label, boolean enabled) {
        this.id = id;
        this.hour = hour;
        this.minute = minute;
        this.label = label;
        this.enabled = enabled;
    }

    public String formattedTime() {
        int h12 = hour % 12;
        if (h12 == 0) h12 = 12;
        return String.format("%02d:%02d %s", h12, minute, hour < 12 ? "AM" : "PM");
    }
}
