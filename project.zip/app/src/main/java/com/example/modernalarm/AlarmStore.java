package com.example.modernalarm;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class AlarmStore {
    private static final String P = "alarms_pref";
    private static final String K = "list";

    public static List<Alarm> load(Context c) {
        List<Alarm> list = new ArrayList<>();
        SharedPreferences sp = c.getSharedPreferences(P, Context.MODE_PRIVATE);
        try {
            JSONArray arr = new JSONArray(sp.getString(K, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                list.add(new Alarm(o.getLong("id"), o.getInt("h"), o.getInt("m"),
                        o.optString("label", ""), o.optBoolean("enabled", true)));
            }
        } catch (Exception ignored) {
        }
        return list;
    }

    public static void save(Context c, List<Alarm> list) {
        JSONArray arr = new JSONArray();
        try {
            for (Alarm a : list) {
                JSONObject o = new JSONObject();
                o.put("id", a.id);
                o.put("h", a.hour);
                o.put("m", a.minute);
                o.put("label", a.label);
                o.put("enabled", a.enabled);
                arr.put(o);
            }
        } catch (Exception ignored) {
        }
        c.getSharedPreferences(P, Context.MODE_PRIVATE)
                .edit().putString(K, arr.toString()).apply();
    }
}
