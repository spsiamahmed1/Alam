package com.example.modernalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;

        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            for (Alarm a : AlarmStore.load(context)) {
                if (a.enabled) AlarmScheduler.schedule(context, a);
            }
            return;
        }

        long id = intent.getLongExtra("alarmId", -1);
        String label = intent.getStringExtra("label");

        Intent ring = new Intent(context, RingActivity.class);
        ring.putExtra("alarmId", id);
        ring.putExtra("label", label);
        ring.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        context.startActivity(ring);
    }
}
